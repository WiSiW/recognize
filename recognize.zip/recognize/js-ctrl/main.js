﻿(function () {
    //var recorder;
    var that = me.define("main", {
        ctrl: function () {
        },
        showRecognize: function () {
            me.show("recognize", {
                showType: 1,
                style: "pop",
                param: {}
            }).on("hide", function (data) {
                $(".recognize").val(data)
            });
        }
    });
})();