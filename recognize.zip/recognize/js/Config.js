﻿var Config = {
    api: "http://192.168.1.19:8075/api/{method}",
    //res: "http://oss.aliyuncs.com/med100/",
    res: "http://res.ipathology.cn/",
    /*获取切片label图片*/
    SLIDE_LABEL_INTERFACE: "http://slides.med100.cn/getLabelImage/?fileName=",
    /*获取切片缩略图*/
    SLIDE_THUMBIMAGE_INTERFACE: "http://slides.med100.cn/getThumbImage/?fileName=",
    pythonServer: "http://slides.med100.cn/",
    pythonServerLabel: "http://member.med100.cn/yue/",
    slides_url:"http://chat.ipathology.cn/slide?fileName="
};
