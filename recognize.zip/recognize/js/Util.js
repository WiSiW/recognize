﻿var Util = (function () {
	var that;
	var obj = function () {
		this.ajaxCount = 0;
		that = this;
		that.popId = [];

	};

	obj.prototype = {
		getQueryString: function (name) {
			var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
			var r = window.location.search.substr(1).match(reg);
			if (r != null) return decodeURIComponent(r[2]);
			return "";
		},

		info: function (msg, success) {
			$(".util_pop_info").remove();

			var innerDiv = document.createElement("div");
			innerDiv.className = "util_pop_info";
			if (success) {
				innerDiv.className += " success";
			}
			innerDiv.innerHTML = msg;

			document.body.appendChild(innerDiv);
			setTimeout(function () {
				$(".util_pop_info").remove();
			}, 3000);
		},

		getApiUrl: function (method, param) {
			var url;
			if (method && method.indexOf("http://") >= 0)
				url = method;
			else {
			    url = Config.api.replace("{method}", method);
			}

			if (param) {
				if (url.indexOf("?") < 0) url += "?";
				for (var key in param) {
					url += key + "=" + param[key] + "&";
				}
				url = url.substring(0, url.length - 1);
			}
			return url;
		},

		ajax: function (option, callback, noloading) {
		    /*默认添加token参数*/
		    if (!option.data.token) {
		      option.data.token = Util.getQueryString("token");
		    }

			if (!option.data.token && me.global.login_data) {
				option.data.token = me.global.login_data.token;
			}
		    //if (!noloading) that.showLoading();

		    var startTime = new Date();
		    me.ajax(option, function (data) {
		        if (!noloading) that.hideLoading();

		        if (me._param.config.debug) {
		            console.group && console.group("ajax");
		            console.log("%c链接", "font-weight:bold;");
		            console.log(option.url);
		            console.log("%c参数", "font-weight:bold;");
		            console.log(JSON.stringify(option.data))
		            console.log("%c返回", "font-weight:bold;");
		            console.log(data.data);
		            console.log("%c执行时间 " + (new Date() - startTime), "font-weight:bold;");
		            console.groupEnd && console.groupEnd();
		        }

		        if (data.resultCode && data.resultCode != "0") {
		            data.resultMsg && Util.info(data.resultMsg);

		            //if (data.resultCode == 100) {
		            //    location.replace("login.html");
		            //    return;
		            //}

		            return;
		        }

		        callback(data.data);
		    }, function (msg, status) {
		        if (!noloading) that.hideLoading();
		        if (status != 0) Util.info("请重试");
		    });
		},

		showLoading: function () {
			this.ajaxCount++;

			var loading = document.getElementById("loading");
			if (!loading) {
				loading = document.createElement("div");
				loading.id = "loading";
				loading.innerHTML = "<img src='images/loading.gif' />";
				document.body.appendChild(loading);
			}
		},

		hideLoading: function () {
			this.ajaxCount--;
			if (this.ajaxCount <= 0) {
				var loading = document.getElementById("loading");
				if (loading) {
					document.body.removeChild(loading);
				}
				this.ajaxCount = 0;
			}
		},

		toMax: function () {
			var gui = require('nw.gui');
			var win = gui.Window.get();
			win.maximize();
		},

		clearCache: function () {
			require("nw.gui").App.clearCache();
		},

		toMap: function (arr, idField) {
			if (!arr) return {};

			var map = {};
			arr.forEach(function (item) {
				map[item[idField]] = item;
			});
			return map;
		},

		confirm: function (title, content, $timeout, callback) {
		    this.pop(title, content, $timeout, callback, false, true);
		},

		pop: function (title, content, $timeout, callback, noCancel,
            confirmValueFn, cancelFn, nobtn, width) {
		    var dialog_shadow = document.createElement("div");
		    var pId = that._getRandomId();

		    Util.popId.push(pId);

		    dialog_shadow.id = pId;
		    dialog_shadow.className = "dialog_shadow";

		    var pageStyle = "max-height:"
                + (document.documentElement.clientHeight - 249) + "px;";
		    var html = '<div class="dialog" '
                + (width ? "style='width:" + width + "px'" : "") + '>'
                + '<div class="dialog_hd">' + '<span class="dialog_title">'
                + title + '</span>'
                + '<a  id="dialog_closed"></a>'
                + '</div>' + '<div class="dialog_content" style="'
                + pageStyle + '">' + content + '</div>'
                + '<div class="dialog_ft" '
                + (nobtn ? "style='display:none;'" : "") + '>';
		    if (!noCancel) {
		        html += '<input type="button" class="button middle" value='
                    + imageView.getLabelText("LABEL_9")
                    + ' id="dialog_cancel" />';
		    }
		    html += '<input type="button" class="button middle yellow" value='
                + imageView.getLabelText("LABEL_25")
                + ' id="dialog_confirm" />';
		    html += '</div></div>';
		    dialog_shadow.innerHTML = html;
		    document.body.appendChild(dialog_shadow);

		    this._bindDialogEvent("#dialog_confirm", confirmValueFn, $timeout,
                callback);
		    this._bindDialogEvent("#dialog_closed", false, $timeout, cancelFn);
		    if (!noCancel) {
		        this._bindDialogEvent("#dialog_cancel", false, $timeout,
                    cancelFn);
		    }

		    return dialog_shadow;
		},

		_bindDialogEvent: function (selector, result, $timeout, callback) {
		    var dialog_shadow = document
                .getElementById(Util.popId[Util.popId.length - 1]);
		    dialog_shadow
                .querySelector(selector)
                .addEventListener(
                    "click",
                    function () {
                        var value = (typeof result) == "function" ? result(document
                            .getElementById(Util.popId[Util.popId.length - 1]))
                            : result;
                        if (value == undefined) {
                            return;
                        }

                        document.body
                            .removeChild(document
                                .getElementById(Util.popId[Util.popId.length - 1]));
                        Util.popId.pop();
                        Util._callback(callback, value, $timeout);
                    }, false);
		},

		_callback: function (callback, result, $timeout) {
		    if (!callback)
		        return;

		    if ($timeout)
		        $timeout(function () {
		            callback(result);
		        });
		    else
		        callback(result);
		},

		_getRandomId: function () {
		    return "ID" + Math.random().toString().substring(2);
		},


		doUploadFile: function (data, accept, maxSize, callBack) {
			File.upload({
				multi: false,
				url: Util.getApiUrl("upload/uploadfile"),
				param: data,
				accept: accept,
				before: function (files) {
					if(!maxSize){
						if (files[0].size > maxSize * 1024) {
							Util.info("图像大小不能超过"+maxSize+"KB");
							return false;
						}
					}
					//Util.showLoading();
				},
				after: function (data) {
					Util.hideLoading();
					data = JSON.parse(data).data;
					callBack && callBack(data);
				},
				error: function () {
					Util.hideLoading();
					Util.info("上传失败");
				},
				progress: function () { }
			});
		},

		/*设置cookie*/
		setCookie: function (name, value) {
			var Days = 30;
			var exp = new Date();
			exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
			document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString();
		},

        //
		//getCookie:function(cookieName) {
		//	var strCookie = document.cookie;
		//	var arrCookie = strCookie.split("; ");
		//	for(var i = 0; i < arrCookie.length; i++){
		//		var arr = arrCookie[i].split("=");
		//		if(cookieName == arr[0]){
		//			return arr[1];
		//		}
		//	}
		//	return null;
		//},

		/*删除cookie*/
		removeCookie :function() {
			var cookieName = ["SONOROUS_[984KnLrqu2Bn0Sj]","SONOROUS_[99pKfDu6eyAnqmj]","SONOROUS_[99pKfDu7myBnLej]","SONOROUS_[n9pf9Du6K1K]"];
			for(var i = 0; i<=cookieName.length - 1; i++) {
				var exp = new Date();
				exp.setTime(exp.getTime() - 60*1000);
				var cval = this.getCookie(cookieName[i]);
				console.log(cval);
				if(cval!=null) document.cookie= cookieName[i] + "="+cval+";expires="+exp.toUTCString()+";domain=.ipathology.cn;path=/";
			}
		},


		/*提取cookie*/
		getCookie:function(cookieName) {
			var strCookie = document.cookie;
			var arrCookie = strCookie.split("; ");
			for(var i = 0; i < arrCookie.length; i++){
				var arr = arrCookie[i].split("=");
				if(cookieName == arr[0]){
					return arr[1];
				}
			}
			return null;
		},
		isPhone: function (phone) {
		    return /^1[358]\d{9}$/.test(phone);
		},

		isNum: function (num) {
		    return /^\d+(\.\d+)?$/.test(num);
		},

		isInteger: function (num) {
		    return /^\d+$/.test(num);
		},

		decentString: function (str) {
		    return /^[a-zA-Z_\d]+$/.test(str);
		},

		decentStringZH: function (str) {
		    return /^[a-zA-Z_\d\u4e00-\u9fa5]+$/.test(str);
		},

		idnumber: function (str) {
		    var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
		    return reg.test(str);
		},

		isMail: function (str) {
		    return /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(str);
		},

		//获取字符串长度
		getBLen: function(str) {
			if (str == null) return 0;
			if (typeof str != "string"){
				str += "";
			}
			return str.replace(/[^\x00-\xff]/g,"01").length;
		},


		getCookies:function(cookieName) {
			var strCookie = document.cookie;
			var arrCookie = strCookie.split("; ");
			for(var i = 0; i < arrCookie.length; i++){
				var arr = arrCookie[i].split("=");
				if(cookieName == arr[0]){
					return arr[1];
				}
			}
			return null;
		},

		checkCookie:function(callback){
			var cookieOne = that.getCookies("SONOROUS_[984KnLrqu2Bn0Sj]"),
				cookieTwo = that.getCookies("SONOROUS_[99pKfDu6eyAnqmj]"),
				cookieThree = that.getCookies("SONOROUS_[99pKfDu7myBnLej]"),
				cookieFour = that.getCookies("SONOROUS_[n9pf9Du6K1K]");
			if(cookieOne && cookieTwo && cookieThree && cookieFour){
				return {
					"984KnLrqu2Bn0Sj":cookieOne,
					"99pKfDu6eyAnqmj": cookieTwo,
					"99pKfDu7myBnLej": cookieThree,
					"n9pf9Du6K1K": cookieFour
				};
			}
		},

		// 获取浏览器类型和版本
		getExplore: function(){
			var Sys = {};
			var ua = navigator.userAgent.toLowerCase();
			var s;
			(s = ua.match(/rv:([\d.]+)\) like gecko/)) ? Sys.ie = s[1] :
				(s = ua.match(/msie ([\d\.]+)/)) ? Sys.ie = s[1] :
					(s = ua.match(/edge\/([\d\.]+)/)) ? Sys.edge = s[1] :
						(s = ua.match(/firefox\/([\d\.]+)/)) ? Sys.firefox = s[1] :
							(s = ua.match(/(?:opera|opr).([\d\.]+)/)) ? Sys.opera = s[1] :
								(s = ua.match(/chrome\/([\d\.]+)/)) ? Sys.chrome = s[1] :
									(s = ua.match(/version\/([\d\.]+).*safari/)) ? Sys.safari = s[1] : 0;
			// 根据关系进行判断
			if (Sys.ie) return ({type:'IE', edition: Sys.ie});
			if (Sys.edge) return ({type:'EDGE', edition:Sys.edge});
			if (Sys.firefox) return ({type:'Firefox', edition:Sys.firefox});
			if (Sys.chrome) return ({type:'Chrome', edition:Sys.chrome});
			if (Sys.opera) return ({type:'Opera', edition:Sys.opera});
			if (Sys.safari) return ({type:'Safari', edition:Sys.safari});
			return 'Unkonwn';
		},
		getNowFormatDate:function () {
			var date = new Date();
			var seperator1 = "-";
			var seperator2 = ":";
			var month = date.getMonth() + 1;
			var strDate = date.getDate();
			if (month >= 1 && month <= 9) {
				month = "0" + month;
			}
			if (strDate >= 0 && strDate <= 9) {
				strDate = "0" + strDate;
			}
			var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
				+ " " + date.getHours() + seperator2 + date.getMinutes()
				+ seperator2 + date.getSeconds();
			return currentdate;
		}
	};

	return new obj();
})();