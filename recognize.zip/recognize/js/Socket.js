﻿var Service = (function () {
	var address = 'ws://192.168.1.43:4001/';
	var timeout = 10000;
	var that;

	var obj = function () {
		that = this;
		that.init();
	};

	obj.prototype = {
		init: function () {
			that.callbackCache = {};
			that.fixCallback = null;
			that.isOpen = false;

			that.ws = new WebSocket(address);
			that.ws.onmessage = that._onmessage;
			that.ws.onopen = that._onopen;
			that.ws.onclose = that._onclose;
		},

		send: function (param, callback, _time) {
			if (!that.isOpen) {
				setTimeout(function () {
					_time = _time || 1000;

					if (_time >= timeout) {
						that._onclose();
					} else {
						_time += 1000;
						that.send(param, callback, _time);
					}
				}, 1000);
				return;
			}

			param = param || {};
			param.CmdSeq = that._getRandom();

			if (callback) {
				that.callbackCache[param.CmdSeq] = callback;
			}
			
			that.ws.send(JSON.stringify(param));
		},

		_onmessage: function (evt) {
			var data = JSON.parse(evt.data);
			if (data.CmdSeq in that.callbackCache) {
				that.callbackCache[data.CmdSeq](data);
				that.callbackCache[data.CmdSeq] = null;
				delete that.callbackCache[data.CmdSeq];
			} else if (typeof that.fixCallback == "function") {
				that.fixCallback(data);
			}
		},

		_onopen: function () {
			that.isOpen = true;
		},

		_onclose: function () {
			that.isOpen = false;
			if (that.onclose) {
				that.onclose();
			} else {
				alert("无法连接服务器，请稍后重试");
			}
		},

		_getRandom: function () {
			return "i" + Math.random().toString().substring(2);
		}
	};

	return new obj();
})();