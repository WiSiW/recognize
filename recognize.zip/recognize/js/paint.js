﻿var Paint = (function () {
	var RES_FINISH = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABMAAAAPCAYAAAAGRPQsAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzlDMURFMTcwODI4MTFFNThBODdFOEJFQzdBNzFEMzQiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzlDMURFMTgwODI4MTFFNThBODdFOEJFQzdBNzFEMzQiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3OUMxREUxNTA4MjgxMUU1OEE4N0U4QkVDN0E3MUQzNCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3OUMxREUxNjA4MjgxMUU1OEE4N0U4QkVDN0E3MUQzNCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pl5VBhsAAACISURBVHjaYnz68gMDmaAIid0HIpgoMaj5WGgvMp+RDJehG8RQa7W6mByXYRiEzGfBFwbEGITNZVjDgBSDQA5gQleIxUCiDIK7DFcYkGIQ3DAkCQwDiTUIOWngdAGxBiFHQB8uFxJrEHo6w2sgIYOwJVqsBhJjEK4cgGIgsQYRypuEcgQGAAgwALLQWxXLd3JGAAAAAElFTkSuQmCC",
		RES_CLOSE = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6RjM5MjM1MTQwODI4MTFFNThBQzRGRTBFRDVCQkU5NDciIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6RjM5MjM1MTUwODI4MTFFNThBQzRGRTBFRDVCQkU5NDciPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpGMzkyMzUxMjA4MjgxMUU1OEFDNEZFMEVENUJCRTk0NyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpGMzkyMzUxMzA4MjgxMUU1OEFDNEZFMEVENUJCRTk0NyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pk32ncoAAACKSURBVHjapJPRCYAwDESbczbHEHQyBcdwHj/8cwFBCwVDmksF8/vukvRCZT/OVGpMby2propDg27oZ0dIuTyTLUjXuk1qAuWwwJvAOMykSmCNWi8lsJEJmTE/CTo9bwNm1Gk3G1ijNYere2fEFyNrgMgYXSH70DJGDdw723AYhxU4qVIuf37VLcAAUC9p74FuxhsAAAAASUVORK5CYII=";

	var obj = function (container, options) {
	    this.container = typeof container == "string" ? document.querySelector(container) : container;
	    this.options = {
	        color: "red",
	    	calibration: null
	    };
	    if (options) {
	        for (var i in options) {
	            this.options[i] = options[i];
	        }
	    }

		this._buildCanvas();
	}

	obj.prototype = {
		drawRectangle: function (callback) {
			var canvas = this.canvas,
				that = this;

			canvas.onmousedown = function (event) {
				var origin = that._getEventPos(event),
					point;

				canvas.onmousemove = function (event) {
					point = that._getEventPos(event);
					that._draw("rectangle", {
						origin: origin,
						point: point
					});
					that.calculate("rectangle", [origin.x, origin.y, point.x, point.y]);

				}

				canvas.onmouseup = function () {
					canvas.onmousemove = null;
					canvas.onmouseup = null;
					if (!point) return;
				
					canvas.onmousedown = null;

					var p1 = {
						x: Math.min(origin.x, point.x),
						y: Math.min(origin.y, point.y)
					};
					var p2 = {
						x: Math.max(origin.x, point.x),
						y: Math.max(origin.y, point.y)
					};
					callback && callback([p1.x, p1.y, p2.x, p2.y],
						that.calculate("rectangle", [origin.x, origin.y, point.x, point.y]));
				}
			}
		},
		drawScreenShot: function (callback,options) {
		    this._cover();
		    options = options || {};
			var canvas = this.canvas,
				that = this;
			var cw, ch, cwo, cho;
			canvas.onmousedown = function (event) {
				var origin = that._getEventPos(event),
					point;

				canvas.onmousemove = function (event) {
				    $(".paint_options").remove();
				    point = that._getEventPos(event);
				    cw = point.x - origin.x;
				    ch = point.y - origin.y;
				    cwo = ch / 0.75;
				    cho = cw * 0.75;

				    if (Math.abs(cw - cwo) > Math.abs(ch - cho))
				    {
				        point.y = (ch > 0) ? ((cho > 0) ? cho + origin.y : origin.y - cho) : ((cho > 0) ?origin.y - cho: cho + origin.y );
                    }
                    else {
				        point.x = (cw > 0) ? ((cwo > 0) ? cwo + origin.x : origin.x - cwo) : ((cwo < 0) ?origin.x - cwo: cwo + origin.x );
				    }

                    //截图限制大小
				    if ((options.maxwidth && cw > options.maxwidth) || (options.maxheight && ch > options.maxheight))
				        return;
				    //截图不可超出边界
				    if (point.y >= options.canvas.height || point.x >= options.canvas.width || point.x <= 0 || point.y <= 0)
				        return;

					that._draw("screenshot", {
						origin: origin,
						point: point
					});
				}

				canvas.onmouseup = function () {
					canvas.onmousemove = null;
					canvas.onmouseup = null;
					if (!point) return;
				
					canvas.onmousedown = null;

					var p1 = {
						x: Math.min(origin.x, point.x),
						y: Math.min(origin.y, point.y)
					};
					var p2 = {
						x: Math.max(origin.x, point.x),
						y: Math.max(origin.y, point.y)
					};

					canvas.onmousedown = function (ev) {
					    var oEvent = ev || event;       
					    var origin = that._getEventPos(oEvent),
                            point, p0, p3;

					    canvas.onmousemove = function (ev) {
					        $(".paint_options").remove();
					        var oEvent = ev || event;
					        point = that._getEventPos(oEvent);
					        cw = point.x - origin.x;
					        ch = point.y - origin.y;

					        p0 = { x: p1.x + cw, y: p1.y + ch };
					        p3 = { x: p2.x + cw, y: p2.y + ch };

					        //截图限制大小
					        if ((options.maxwidth && cw > options.maxwidth) || (options.maxheight && ch > options.maxheight))
					            return;
					        //截图不可超出边界
					        if (p2.y + ch >= options.canvas.height || p1.x + cw <= 0 || p1.y + ch <= 0 || p2.x + cw >= options.canvas.width) {
					            return;
					        }
					        
					        that._draw("screenshot", {
					            origin: p0,
					            point: p3
					        });

					    }
					    canvas.onmouseup = function (ev) {
					        canvas.onmousemove = null;
					        canvas.onmouseup = null;
					        if (!point) return;

					        p1 = {
					            x: Math.min(p0.x, p3.x),
					            y: Math.min(p0.y, p3.y)
					        };
					        p2 = {
					            x: Math.max(p0.x, p3.x),
					            y: Math.max(p0.y, p3.y)
					        };
					        that._moveEnd(
						        [p1.x, p1.y, p2.x, p2.y],
						        [p1.x, p1.y, p2.x, p2.y], callback);
					    }
					}
					that._moveEnd(
                        [p1.x, p1.y, p2.x, p2.y],
                        [p1.x, p1.y, p2.x, p2.y], callback);

				}
			}
		},

        //画固定尺寸的截屏
		drawFixedScreenShot: function (options,callback) {
		    this._cover();
		    options = options || {};
		    var canvas = this.canvas,
				that = this;
		    var cw, ch, cwo, cho;
		    var origin = {
		        x: (this.canvas.width - options.width) / 2,
		        y: (this.canvas.height - options.height) / 2
		    };
		    var point = { x: origin.x + options.width, y: origin.y + options.height };

		    var p1 = {
		        x: Math.min(origin.x, point.x),
		        y: Math.min(origin.y, point.y)
		    };
		    var p2 = {
		        x: Math.max(origin.x, point.x),
		        y: Math.max(origin.y, point.y)
		    };

		    that._draw("screenshot", {
		        origin: origin,
		        point: point
		    });

		    canvas.onmousedown = function (ev) {
		        var oEvent = ev || event;
		        var origin = that._getEventPos(oEvent),
                    point, p0, p3;

		        canvas.onmousemove = function (ev) {
		            $(".paint_options").remove();
		            var oEvent = ev || event;
                    //获取鼠标位置
		            point = that._getEventPos(oEvent);
		            cw = point.x - origin.x;
		            ch = point.y - origin.y;

                    //计算左上角、右下角坐标
		            p0 = { x: p1.x + cw, y: p1.y + ch };
		            p3 = { x: p2.x + cw, y: p2.y + ch };

                    //不可超出左边界
		            if (p0.x < 0) {
		                p0.x = 0;
		                p3.x = options.width;
		            }

		            //不可超出上边界
		            if (p0.y < 0) {
		                p0.y = 0;
		                p3.y = options.height;
		            }

		            //不可超出右边界
		            if (p3.x >canvas.width) {
		                p3.x = canvas.width;
		                p0.x =canvas.width - options.width;
		            }

		            //不可超出下边界
		            if (p3.y > canvas.height) {
		                p3.y = canvas.height;
		                p0.y = canvas.height - options.height;
		            }

                    //将截图视窗移动到指定位置
		            that._draw("screenshot", {
		                origin: p0,
		                point: p3
		            });

		        }
		        canvas.onmouseup = function (ev) {
		            canvas.onmousemove = null;
		            canvas.onmouseup = null;
		            if (!point) return;

		            p1 = {
		                x: Math.min(p0.x, p3.x),
		                y: Math.min(p0.y, p3.y)
		            };
		            p2 = {
		                x: Math.max(p0.x, p3.x),
		                y: Math.max(p0.y, p3.y)
		            };
		            that._moveEnd(
                        [p1.x, p1.y, p2.x, p2.y],
                        [p1.x, p1.y, p2.x, p2.y], callback);
		        }
		    }
		    
		    that._moveEnd(
                      [p1.x, p1.y, p2.x, p2.y],
                      [p1.x, p1.y, p2.x, p2.y], callback);
		},

		drawCircle: function (callback) {
			var canvas = this.canvas,
				that = this;

			canvas.onmousedown = function (event) {
				var origin = that._getEventPos(event),
					center,
					r;

				canvas.onmousemove = function (event) {
					var point = that._getEventPos(event);

					// 圆心坐标
					center = {
						x: (point.x - origin.x) / 2 + origin.x,
						y: (point.y - origin.y) / 2 + origin.y
					};

					// 半径
					r = Math.abs(center.x - origin.x);

					that._draw("circle", {
						center: center,
						r: r
					});
					that.calculate("circle", r);
				}

				canvas.onmouseup = function () {
					canvas.onmousemove = null;
					canvas.onmouseup = null;
					if (!center) return;
				
					canvas.onmousedown = null;

					callback && callback([center.x - r, center.y - r, center.x + r, center.y + r],
						that.calculate("circle", r));
				}
			}
		},

	    //画固定尺寸的圆圈
		drawFixedCircle: function (circle, callback) {
		    var canvas = this.canvas,
				that = this;
		    if (circle.center) {
		        origin = circle.center;
		        that._draw("circle", {
		            center: origin,
		            r: circle.r
		        });
		        that.calculate("circle", circle.r);
		        callback && callback([origin.x - circle.r, origin.y - circle.r, origin.x + circle.r, origin.y + circle.r],
                            that.calculate("circle", circle.r));
		    }
		    else {
		        canvas.onmousedown = function (event) {
		            var origin = that._getEventPos(event);
		            that._draw("circle", {
		                center: origin,
		                r: circle.r
		            });
		            that.calculate("circle", circle.r);
		            callback && callback([origin.x - circle.r, origin.y - circle.r, origin.x + circle.r, origin.y + circle.r],
                                that.calculate("circle", circle.r));
		        };
		    }
		},

		drawMeasureline: function(callback) {
			var canvas = this.canvas,
				that = this;

			canvas.onmousedown = function (event) {
				var origin = that._getEventPos(event),
					point,
					head;

				canvas.onmousemove = function (event) {
					point = that._getEventPos(event);
					
					head = that._draw("measure", {
						origin: origin,
						point: point
					});
				}

				canvas.onmouseup = function () {
					canvas.onmousemove = null;
					canvas.onmouseup = null;
					if (!point) return;
				
					canvas.onmousedown = null;
					callback && callback([origin.x, origin.y, point.x, point.y]);
				}
			}
		},
		drawPen: function (callback) {
			var canvas = this.canvas,
				context = this.context,
				that = this;

			canvas.onmousedown = function (event) {
				var origin = that._getEventPos(event),
					point,
					path = [],
					minX = 100000,
					minY = 100000,
					maxX = 0,
					maxY = 0;

				if (origin.x < minX) minX = origin.x;
				if (origin.y < minY) minY = origin.y;
				if (origin.x > maxX) maxX = origin.x;
				if (origin.y > maxY) maxY = origin.y;

				path.push(origin);
				context.beginPath();
				context.moveTo(origin.x, origin.y);

				canvas.onmousemove = function (event) {
					point = that._getEventPos(event);

					if (point.x < minX) minX = point.x;
					if (point.y < minY) minY = point.y;
					if (point.x > maxX) maxX = point.x;
					if (point.y > maxY) maxY = point.y;

					path.push(point);
					context.lineTo(point.x, point.y);
					context.stroke();
					that.calculate("pen", {
					    path: path,
					    isWhole: false
					});
				}

				canvas.onmouseup = function () {
					canvas.onmousemove = null;
					canvas.onmouseup = null;

					if (!point) return;

					context.lineTo(path[0].x, path[0].y);
					context.stroke();

					context.save();
					context.globalCompositeOperation = 'destination-out';
					context.closePath();
					context.fill();
					context.restore();
					path.forEach(function (p) {
						p.x -= minX;
						p.y -= minY;
					});

					canvas.onmousedown = null;
					callback && callback({
							path: path,
							minX: minX,
							minY: minY,
							maxX: maxX,
							maxY: maxY
					},
						that.calculate("pen", {
						    path: path,
						    isWhole: true
						}));
				}
			}
		},

		drawArrow: function(callback) {
			var canvas = this.canvas,
				that = this;

			canvas.onmousedown = function (event) {
				var origin = that._getEventPos(event),
					point,
					head;

				canvas.onmousemove = function (event) {
					point = that._getEventPos(event);
					
					head = that._draw("arrow", {
						origin: origin,
						point: point
					});
				}

				canvas.onmouseup = function () {
					canvas.onmousemove = null;
					canvas.onmouseup = null;
					if (!point) return;
				
					canvas.onmousedown = null;
					callback && callback([origin.x, origin.y, point.x, point.y]);
				}
			}
		},

		destory: function () {
			this.container.innerHTML = "";
		},
		_moveEnd: function (pos, data, callback, calculate) {
		    pos[0] = Math.max(pos[0], 0);
		    pos[1] = Math.max(pos[1], 0);
		    pos[2] = Math.min(pos[2], this.canvas.width);
		    pos[3] = Math.min(pos[3], this.canvas.width);

		    data[0] = Math.max(data[0], 0);
		    data[1] = Math.max(data[1], 0);
		    data[2] = Math.min(data[2], this.canvas.width);
		    data[3] = Math.min(data[3], this.canvas.width);
			var that = this;
			$(".paint_options").remove();
			// 如果画的区域在屏幕底部，那么工具条放在上面
			var _top = (pos[3] + 5);
			if (_top > this.canvas.height - 30) {
				_top = pos[1] - 40;
			}

			var ul = document.createElement("ul");
			ul.className = "paint_options";
			ul.style.cssText = "right:" + Math.max(5, (this.canvas.width - pos[2]))
				+ "px;top:" + Math.max(_top, 5) + "px;";

			// 取消截图
			var li = document.createElement("li");
			li.title = "取消";
			li.style.cssText = "width:15px;background:url(" + RES_CLOSE
				+ ") center center no-repeat;";
			li.onclick = function () {
				$(".paint_options").remove();
				that.destory();
				document.getElementById("iv_sh_wh").style.visibility = "hidden";
				if (that.options.cancel) that.options.cancel();
			}
			ul.appendChild(li);

			// 点击完成截图
			li = document.createElement("li");
			li.innerHTML = "确定";
			li.title = "点击保存截图";
			li.style.cssText = "padding-left:25px;background:url(" + RES_FINISH
				+ ") left center no-repeat;";
			li.onclick = function () {
			    if (callback) callback(data, calculate);
			    $(".paint_options").remove();
			    document.getElementById("iv_sh_wh").style.visibility = "hidden";
			}
			ul.appendChild(li);

			this.container.appendChild(ul);
		},

		_buildCanvas: function () {
			var containerSize = this.container.getBoundingClientRect();
			var canvas = document.createElement("canvas");
			canvas.width = containerSize.width;
			canvas.height = containerSize.height;
			canvas.style.cssText = "position:absolute;left:0;top:0;cursor: crosshair;";
			this.container.innerHTML = "";
			this.container.appendChild(canvas);

			this.canvas = canvas;
			this.bbox = this.canvas.getBoundingClientRect();
			this.context = canvas.getContext('2d');
			this.context.strokeStyle = this.options.color;
			this.context.lineWidth = 3;
		},

		_draw: function (type, data) {
			this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
			switch (type) {
				case "rectangle":
					var origin = data.origin, // 左上角坐标
						point = data.point, // 右下角坐标
						width = point.x - origin.x, // 矩形的宽度
						height = point.y - origin.y; // 矩形的高度

					this.context.beginPath();
					this.context.strokeRect(origin.x, origin.y, width, height);
					this.context.clearRect(origin.x, origin.y, width, height);
					this.context.closePath();
					break;
			    case "screenshot":
					this._cover();
					var origin = data.origin, // 左上角坐标
						point = data.point, // 右下角坐标
						width = point.x - origin.x, // 矩形的宽度
						height = point.y - origin.y; // 矩形的高度
					this.context.beginPath();
					this.context.strokeRect(origin.x, origin.y, width, height);
					this.context.clearRect(origin.x, origin.y, width, height);
					this.context.closePath();
					var result = document.getElementById("iv_sh_wh");
					result.innerHTML = width + " x " + height;
					result.style.top = (origin.y-20) + "px";
					result.style.left = origin.x + "px";
					result.style.visibility = "visible";
					
					break;

				case "circle":
				    //this.context.save();
				    //this.context.globalCompositeOperation = 'destination-out';
				    this.context.beginPath();
					this.context.arc(data.center.x, data.center.y, data.r, 0, 2 * Math.PI);
					this.context.stroke();
					this.context.closePath();
					//this.context.strokeStyle = this.options.color;
					//this.context.fill();
					//this.context.restore();
					break;
				case "measure":
					var origin = data.origin, 
						point = data.point;
					
					// 主线
					this.context.beginPath();
					this.context.moveTo(origin.x,origin.y);
					this.context.lineTo(point.x,point.y);
										
					this.context.stroke();
					break;
				case "arrow":
					var origin = data.origin, 
						point = data.point;
					
					// 箭头主线
					this.context.beginPath();
					this.context.moveTo(origin.x,origin.y);
					this.context.lineTo(point.x,point.y);
					
					// 箭头
					var h = this._calcArrowHead({}, origin, point);
					this.context.moveTo(point.x, point.y);
					this.context.lineTo(h.h1.x, h.h1.y);
					this.context.moveTo(point.x, point.y);
					this.context.lineTo(h.h2.x, h.h2.y);
					
					this.context.stroke();
					return h;
			}
		},

		_getEventPos: function (event) {
			//TODO 获取x,y坐标的方式适配移动设备
			var x = event.clientX,
				y = event.clientY;

			return {
				x: x - this.bbox.left - (this.bbox.width - this.canvas.width) / 2,
				y: y - this.bbox.top - (this.bbox.height - this.canvas.height) / 2
			};
		},
		
		_calcArrowHead: function(a, sp, ep) {
			var theta = Math.atan((ep.x - sp.x) / (ep.y - sp.y));
			var cep = this._scrollXOY(ep, -theta);
			var csp = this._scrollXOY(sp, -theta);
			var ch1 = {
				x: 0,
				y: 0
			};
			var ch2 = {
				x: 0,
				y: 0
			};
			var l = cep.y - csp.y;
			ch1.x = cep.x + l * (a.sharp || 0.025);
			ch1.y = cep.y - l * (a.size || 0.05);
			ch2.x = cep.x - l * (a.sharp || 0.025);
			ch2.y = cep.y - l * (a.size || 0.05);
			var h1 = this._scrollXOY(ch1, theta);
			var h2 = this._scrollXOY(ch2, theta);
			return {
				h1: h1,
				h2: h2
			};
		},
		
		_scrollXOY: function(p, theta) {
			return {
				x: p.x * Math.cos(theta) + p.y * Math.sin(theta),
				y: p.y * Math.cos(theta) - p.x * Math.sin(theta)
			};
		},
		_cover: function () {
			var context = this.context;
			context.fillStyle = 'rgba(0,0,0,0.5)';
			context.fillRect(0, 0, this.canvas.width, this.canvas.height);
		},
		_getArea: function (point) {
		    var i, s,
				vcount = point.length;

		    if (vcount < 3) return 0;

		    s = point[0].y * (point[vcount - 1].x - point[1].x);
		    for (i = 1; i < vcount; i++) {
		        s += point[i].y * (point[(i - 1)].x - point[(i + 1) % vcount].x);
		    }

		    return Math.round(Math.abs(s / 2));
		},
		calculate: function (type, data) {
		    if (!this.options.calibration) return;

		    switch (type) {
		        case "rectangle":
		            if ($("#paint_calculate").length == 0) {
		                var div = document.createElement("div");
		                div.id = "paint_calculate";
		                div.innerHTML = "<div><b>长：</b><i id='paint_calculate_c'></i>μm</div>"
							+ "<div><b>宽：</b><i id='paint_calculate_k'></i>μm</div>"
							+ "<div><b>周长：</b><i id='paint_calculate_zc'></i>μm</div>"
							+ "<div><b>面积：</b><i id='paint_calculate_mj'></i>μm²</div>";

		                this.container.appendChild(div);
		            }

		            var w = (Math.abs(data[2] - data[0])) * this.options.calibration,
						h = (Math.abs(data[3] - data[1])) * this.options.calibration;
		            $("#paint_calculate_c").html(Math.round(w));
		            $("#paint_calculate_k").html(Math.round(h));
		            $("#paint_calculate_zc").html(Math.round((w + h) * 2));
		            $("#paint_calculate_mj").html(Math.round(w * h));

		            return [Math.round(w), Math.round(h), Math.round((w + h) * 2), Math.round(w * h)];

		        case "circle":
		            if ($("#paint_calculate").length == 0) {
		                var div = document.createElement("div");
		                div.id = "paint_calculate";
		                div.innerHTML = "<div><b>半径：</b><i id='paint_calculate_r'></i>μm</div>"
							+ "<div><b>周长：</b><i id='paint_calculate_zc'></i>μm</div>"
							+ "<div><b>面积：</b><i id='paint_calculate_mj'></i>μm²</div>";

		                this.container.appendChild(div);
		            }

		            var r = Math.round(data * this.options.calibration),
						area = Math.round(Math.PI * r * r),
						zc = Math.round(2 * Math.PI * r);
		            $("#paint_calculate_r").html(r);
		            $("#paint_calculate_zc").html(zc);
		            $("#paint_calculate_mj").html(area);

		            return [r, r, area, zc];

		        case "pen":
		            if ($("#paint_calculate").length == 0) {
		                var div = document.createElement("div");
		                div.id = "paint_calculate";
		                div.innerHTML = "<div><b>周长：</b><i id='paint_calculate_zc'></i>μm</div>"
							+ "<div><b>面积：</b><i id='paint_calculate_mj'></i>μm²</div>";

		                this.container.appendChild(div);
		            }

		            // 周长
		            var zc = 0,
						firstPoint = data.path[0];
		            data.path.forEach(function (point) {
		                zc += Math.sqrt(
							Math.pow(point.x - firstPoint.x, 2)
							+ Math.pow(point.y - firstPoint.y, 2));
		                firstPoint = point;
		            });

		            if (data.isWhole) {
		                zc += Math.sqrt(
							Math.pow(data.path[0].x - data.path[data.path.length - 1].x, 2)
							+ Math.pow(data.path[0].y - data.path[data.path.length - 1].y, 2));
		            }

		            zc = Math.round(this.options.calibration * zc);

		            var area = this._getArea(data.path);
		            $("#paint_calculate_zc").html(zc);
		            $("#paint_calculate_mj").html(area);

		            // 面积
		            //$("#paint_calculate_mj").html(area);

		            return [zc, area];
		    }
		}


	}

	return obj;
})();